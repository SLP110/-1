<template>
    <section class="home-pay">
        <div id='content'>
            <div class='box'>
                    <div class='giveconts'>您正在向海底捞付款</div>
                    <div class='user-money'>
                            <text style='font-size:40rpx;'>消费金额</text>
                            <text style='margin-left:60rpx;' class='user-export'>询问服务员后输入</text>
                    </div>

                    <div class='user-money1'>
                            <text style='font-size:30rpx;'>支付方式</text>
                            <text style='color:black;margin-left:205rpx; font-size:30rpx;' class='user-export1'>余额支付<font style='color:red;'>></font>

                            </text>
                    </div>


                    <div class='user-money1'>
                            <text style='font-size:30rpx;'>使用优惠券</text>
                            <text style='color:black;margin-left:205rpx; font-size:30rpx;' class='user-export1'>最大优惠券10元<text style='color:red;'></text></text>
                    </div>


                    <div class='user-money1'>
                            <text style='font-size:30rpx;'>实付金额</text>
                            <text style='color:black;margin-left:205rpx;' class='user-export1'><text style='color:red;'>¥</text>0</text>
                    </div>

                    <div class='zhifu' bindtap='payment'>支付</div>

            </div>
        </div>
    </section>
</template>


<script>
export default {
   data(){
        return {
            
        }
    },
    methods:{

    },
    computed:{

    }
}
</script>

<style lang="scss" >
    /* pages/money/money.wxss */
/* *{
        font-size:30rpx;
} */

#content{
        width:100%;
        /* height:667rpx; */
        background: rgba(238, 238, 243, 0.8);
        margin:auto;
}
#content  .box{
        width:90%;
        height: auto;
        /* background: red; */
        margin: auto;
}
#content  .box .giveconts{
        width:90%;
        height: 140rpx;
        background:rgb(124, 186, 189);
        border-radius: 15px;
         text-align: center;
        line-height: 100rpx;
        margin-left:30rpx;
}
#content  .box .user-money{
        position: relative;
        top:-60rpx;
        /* margin-top:25rpx; */
        width:100%;
        height: 120rpx;
        border:1px solid orange;
        background:rgb(255, 248, 244);
        border-radius: 12px;
        text-align: center;
        line-height: 120rpx;
}
#content  .box .user-money .user-export{
        color:orange
}
#content  .box .user-money1{
        position: relative;
        top:-60rpx;
        /* margin-top:25rpx; */
        width:100%;
        height: 220rpx;
        border-bottom:1px solid #fff;
        /* background:rgb(255, 248, 244); */
        /* text-align: center; */
        line-height: 150rpx;
        color:gainsboro;
        font-size: 40rpx;
        font-weight: 500;
        margin-left:50rpx;

}
#content  .box .user-money .user-export{
        color:orange;
        margin-top: 180rpx;
}
#content  .box .zhifu{
        width:70%;
        height: 90rpx;
        background:rgb(124, 186, 189);
        margin: auto;
        text-align: center;
        line-height: 100rpx;
        border-radius: 100rpx;
        color:#fff;
        
}
</style>


