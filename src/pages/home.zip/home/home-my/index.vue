<template>
    <section class="home-my">
        <div>1111111111111111</div>
    </section>
</template>


<script>
export default {
   data(){
        return {
            
        }
    },
    methods:{
        
    },
    computed:{

    }
}
</script>

<style lang="scss" >
    
</style>


